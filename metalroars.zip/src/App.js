import React from "react";
import Homepage from './components/homepage/Home'
function App() {
  return (
      <Homepage />
  );
}

export default App;
